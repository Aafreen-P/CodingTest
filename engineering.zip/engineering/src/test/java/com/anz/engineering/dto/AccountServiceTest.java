package com.anz.engineering.dto;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyLong;


import com.anz.engineering.entity.Account;
import com.anz.engineering.repository.AccountRepository;

class AccountServiceTest {

	@InjectMocks
	AccountServiceDTO accountService;
	
	@Mock
	AccountRepository accountRepository;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testRetrieveUsersAccountDetails() {
		//fail("Not yet implemented");
		 List<Account> mockAccountList =new ArrayList<Account>();
			Account mockAccount= new Account("12345567", Long.parseLong("1"), "ANZSaving","Savings",LocalDate.now(),"AUD",10000.0);
		    mockAccountList.add(mockAccount);
		when(accountRepository.findByUserId(anyLong())).thenReturn(mockAccountList);
		List<Account> expectedList= accountService.retrieveUsersAccountDetails((long) 1);
		assertNotNull(expectedList);
		assertEquals("12345567",expectedList.get(0).getAccountNo());
	}

}
