package com.anz.engineering;


import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import com.anz.engineering.dto.AccountServiceDTO;
import com.anz.engineering.entity.Account;
import com.anz.engineering.repository.AccountRepository;


public class AccountControllerTest extends EngineeringApplicationTests{
	
	@InjectMocks
	AccountServiceDTO accountService;
	 
	@Mock
	AccountRepository accountRepository;
	  @Autowired
	  private WebApplicationContext webApplicationContext;
	  private MockMvc mockMvc;

	
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	
	
	// test method For Checking rest url http status is OK --- getAccountDetails for user id 1
	
	String exampleAccountJson = "{\"accountNo\":\"12345567\",\"accountName\":\"ANZSaving\",\"accountType\":\"Savings\",\"balanceDate\":\"2020-12-05T18:30:00.000+00:00\",\"currency\":\"AUD\",\"openingAvailableBalance\":\"10000\",\"userid\":\"1\"}";
	@Test
	public void retrieveAccountDetailsForUser() throws Exception {
		
		
		ResultActions responseResult=mockMvc.perform(get("/getAccountDetails/1").header("contentType", "\"application/json").content(exampleAccountJson));
		responseResult.andExpect(status().isOk());
	}
	
	
	// test method For Checking rest url http status is OK-getTransactionDetails for account number
	
	String exampleTransactionJson = "{\"accountNo\":\"12345567\",\"valueDate\":\"2020-10-05T18:30:00.000+00:00\",\"currency\":\"AUD\",\"debitAmount\":\"0\",\"creditAmount\":\" 1200.550048828125\",\"debitCreditCard\":\"Credit\",\"transactionNarrative\":\"\",\"id\":\"1\"}";

		
	@Test
	public void retrieveTransactionDetails() throws Exception {
		
		
		ResultActions responseResult=mockMvc.perform(get("/getAccountDetails/getTransactionDetails/12345567").header("contentType", "\"application/json").content(exampleTransactionJson));
		responseResult.andExpect(status().isOk());
	}
	
	// test method For Checking rest url http result in JSON
	@Test
	public void retrieveAccountDetailsForUserID() throws Exception {
		
		 List<Account> mockAccountList =new ArrayList<Account>();
			Account mockAccount= new Account("12345567", Long.parseLong("1"), "ANZSaving","Savings",new Date(),"AUD",10000.0);
		    mockAccountList.add(mockAccount);
		when(accountRepository.findByUserId(anyLong())).thenReturn(mockAccountList);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/getAccountDetails/1").accept(
				MediaType.APPLICATION_JSON);
		System.out.println("requestBuilder"+requestBuilder.toString());
	
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		String expected = "[{\"accountNo\":\"12345567\",\"accountName\":\"ANZSaving\",\"accountType\":\"Savings\",\"balanceDate\":\"2020-12-05T18:30:00.000+00:00\",\"currency\":\"AUD\",\"openingAvailableBalance\":10000.0,\"userid\":1}]";
		System.out.println("expected"+expected);
		System.out.println("result::"+result.getResponse().getContentAsString());
		
		JSONAssert.assertEquals(expected, result.getResponse()
				.getContentAsString(), false);
	  }
	}
