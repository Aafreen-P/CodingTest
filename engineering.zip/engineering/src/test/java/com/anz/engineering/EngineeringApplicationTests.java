package com.anz.engineering;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class EngineeringApplicationTests {

	@Test
	public void contextLoads() {
	}

}
