package com.anz.engineering.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anz.engineering.dto.AccountDto;
import com.anz.engineering.dto.AccountTransactionsDto;
import com.anz.engineering.entity.Account;
import com.anz.engineering.entity.AccountTransactions;
import com.anz.engineering.repository.AccountTransactionRepository;
@Service
public class AccountTransactionService {
	@Autowired
	private AccountTransactionRepository transactionRepository;
	public List<AccountTransactionsDto> retrieveUsersTransactionDetails(Long accountNo) {
		List<AccountTransactions> transactionList= transactionRepository.findByAccountNo(accountNo);		 
		List<AccountTransactionsDto> availableTransactionList = new ArrayList<AccountTransactionsDto>();
		for (AccountTransactions at : transactionList) {
			AccountTransactionsDto accountTr = new AccountTransactionsDto();
			accountTr.setTransactionId(at.getId());
			accountTr.setAccountNo(at.getAccountNo());
			accountTr.setValueDate(at.getValueDate());
			accountTr.setCurrency(at.getCurrency());
			accountTr.setDebitAmount(at.getDebitAmount());	
			accountTr.setCreditAmount(at.getCreditAmount());
			accountTr.setDebitCreditCard(at.getDebitCreditCard());
			accountTr.setTransactionNarrative(at.getTransactionNarrative());
			availableTransactionList.add(accountTr);
		}
		
		return availableTransactionList;
	}

}
