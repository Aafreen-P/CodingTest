package com.anz.engineering.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anz.engineering.dto.AccountDto;
import com.anz.engineering.entity.Account;
import com.anz.engineering.repository.AccountRepository;
@Service
public class AccountService {
	@Autowired
	private AccountRepository accountRepository;

	public List<AccountDto> retrieveUsersAccountDetails(Long userId) {
		
		List<Account> accountList= accountRepository.findByUserId(userId);	
		
		List<AccountDto> availableAccountList = new ArrayList<AccountDto>();
		for (Account a : accountList) {
			AccountDto account = new AccountDto();
			account.setAccountNo(a.getAccountNo());
			account.setUserId(a.getUserid());			
			account.setAccountName(a.getAccountName());
			account.setAccountType(a.getAccountType());
            account.setBalanceDate(a.getBalanceDate());		
            account.setCurrency(a.getCurrency());
            account.setOpeningAvailableBalance(a.getOpeningAvailableBalance());
			availableAccountList.add(account);
		}

		return availableAccountList;
	}	
}
