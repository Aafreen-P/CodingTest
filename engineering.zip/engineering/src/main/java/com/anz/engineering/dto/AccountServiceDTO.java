package com.anz.engineering.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anz.engineering.entity.Account;
import com.anz.engineering.repository.AccountRepository;
@Service
public class AccountServiceDTO {
	@Autowired
	private AccountRepository accountRepository;

	public List<Account> retrieveUsersAccountDetails(Long userId) {
		 
		List<Account> AccountList= accountRepository.findByUserId(userId);	
		return AccountList;
	}	
}
