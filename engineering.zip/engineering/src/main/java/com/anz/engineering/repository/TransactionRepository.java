package com.anz.engineering.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.anz.engineering.entity.AccountTransactions;

@Repository
public interface TransactionRepository extends JpaRepository<AccountTransactions, Long>{

	List<AccountTransactions> findByAccountNo(Long accountNo);

}
