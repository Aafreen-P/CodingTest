package com.anz.engineering.entity;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "account_details")
public class Account {

	
	@Id
	private String accountNo;
	private Long userId;
	private String accountName;
	private String accountType;
	private LocalDate  balanceDate;
	private String currency;
	private Double openingAvailableBalance;
	
	protected Account() {
		
	}

		

	public Account(String accountNo, Long userId, String accountName, String accountType, LocalDate balanceDate,
			String currency, Double openingAvailableBalance) {
		super();
		this.accountNo = accountNo;
		this.userId = userId;
		this.accountName = accountName;
		this.accountType = accountType;
		this.balanceDate = balanceDate;
		this.currency = currency;
		this.openingAvailableBalance = openingAvailableBalance;
	}



	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public LocalDate getBalanceDate() {
		return balanceDate;
	}
	public void setBalanceDate(LocalDate balanceDate) {
		this.balanceDate = balanceDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getOpeningAvailableBalance() {
		return Double.valueOf(new DecimalFormat("#.##").format(openingAvailableBalance));
	}
	public void setOpeningAvailableBalance(Double openingAvailableBalance) {
		this.openingAvailableBalance = openingAvailableBalance;
	}
	@Override
	public String toString() {
		return "Account [id=" + userId + ", accountNo=" + accountNo + ", accountName=" + accountName + ", accountType="
				+ accountType + ", balanceDate=" + balanceDate + ", currency=" + currency + ", openingAvailableBalance="
				+ openingAvailableBalance + "]";
	}
	public Long getUserid() {
		return userId;
	}
	public void setUserid(Long userid) {
		this.userId = userid;
	}

	
	
}
