package com.anz.engineering.entity;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction_details")
public class AccountTransactions {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long transactionId;
	private Long accountNo;
	private LocalDate valueDate;
	private String currency;
	private Double debitAmount;
	private Double creditAmount;
	private String debitCreditCard;
	private String transactionNarrative;
	
	public Long getId() {
		return transactionId;
	}
	public void setId(Long id) {
		this.transactionId = id;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public LocalDate getValueDate() {
		return valueDate;
	}
	public void setValueDate(LocalDate valueDate) {
		this.valueDate = valueDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getDebitAmount() {
		return debitAmount;
	}
	public void setDebitAmount(Double debitAmount) {
		this.debitAmount = debitAmount;
	}
	public Double getCreditAmount() {
		return Double.valueOf(new DecimalFormat("#.##").format(creditAmount));
	}
	public void setCreditAmount(Double creditAmount) {
		this.creditAmount = creditAmount;
	}
	public String getDebitCreditCard() {
		return debitCreditCard;
	}
	public void setDebitCreditCard(String debitCreditCard) {
		this.debitCreditCard = debitCreditCard;
	}
	public String getTransactionNarrative() {
		return transactionNarrative;
	}
	public void setTransactionNarrative(String transactionNarrative) {
		this.transactionNarrative = transactionNarrative;
	}
	@Override
	public String toString() {
		return "AccountTransactions [transactionId=" + transactionId + ", accountNo=" + accountNo + ", valueDate="
				+ valueDate + ", currency=" + currency + ", debitAmount=" + debitAmount + ", creditAmount="
				+ creditAmount + ", debitCreditCard=" + debitCreditCard + ", transactionNarrative="
				+ transactionNarrative + "]";
	}
	
	
}
