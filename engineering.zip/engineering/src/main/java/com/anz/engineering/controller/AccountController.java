package com.anz.engineering.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anz.engineering.dto.AccountServiceDTO;
import com.anz.engineering.dto.TransactionServiceDTO;
import com.anz.engineering.entity.Account;
import com.anz.engineering.entity.AccountTransactions;



@RestController
public class AccountController {

	@Autowired
	private AccountServiceDTO accountDto;
	@Autowired
	private TransactionServiceDTO transactionDto;
	

	
	//implementation with mvc --this method returning view with table for user (input is user is)
	@GetMapping(path="/retrieveAccountDetails/{userId}")
	public ModelAndView retrieveAccountDetails(Model model,@PathVariable Long userId){
		 List<Account> accounList=accountDto.retrieveUsersAccountDetails(userId);			 
		 model.addAttribute("AccountList",accounList);
		return new ModelAndView("welcome");
	}
	
	//this method is returning list of account which user holds
	@GetMapping(path="/getAccountDetails/{userId}")
	public List<Account> getUserAccountDetails(@PathVariable Long userId){
		 List<Account> accountList=accountDto.retrieveUsersAccountDetails(userId);			 
		// model.addAttribute("AccountList",accountList);
		return accountList;
	}
	//implementation with mvc --this method returning view with table for transaction on click of account number
	@GetMapping(path="/retrieveAccountDetails/retrieveTransactionDetails/{accountNo}")
	public ModelAndView retrieveTransactionDetails(Model model,@PathVariable Long accountNo){
		 List<AccountTransactions> transactionList=transactionDto.retrieveUsersTransactionDetails(accountNo);
		 model.addAttribute("TransactionList",transactionList);
		return new ModelAndView("welcome");
	}
	
	//this method is returning list of transaction for account which user has selected
	@GetMapping(path="/getAccountDetails/getTransactionDetails/{accountNo}")
	public List<AccountTransactions> getTransactionDetails(@PathVariable Long accountNo){
		 List<AccountTransactions> transactionList=transactionDto.retrieveUsersTransactionDetails(accountNo);		
		 return transactionList;
	}


}
