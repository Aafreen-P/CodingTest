package com.anz.engineering.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.anz.engineering.dto.AccountDto;
import com.anz.engineering.dto.AccountTransactionsDto;
import com.anz.engineering.service.AccountService;
import com.anz.engineering.service.AccountTransactionService;
import com.anz.engineering.ws.exception.ResourceNotFoundException;



@RestController
public class AccountController {

	@Autowired
	private AccountService accountDto;
	@Autowired
	private AccountTransactionService transactionDto;
	

	
	//implementation with mvc --this method returning view with table for user (input is user is)
	@GetMapping(path="/retrieveAccountDetails/{userId}")
	public ModelAndView retrieveAccountDetails(Model model,@PathVariable Long userId){
		 List<AccountDto> accounList=accountDto.retrieveUsersAccountDetails(userId);			 
		 model.addAttribute("AccountList",accounList);
		return new ModelAndView("welcome");
	}
	
	//this method is returning list of account which user holds
	@GetMapping(path="/getAccountDetails/{userId}")
	public List<AccountDto> getUserAccountDetails(@PathVariable Long userId){
		 List<AccountDto> accountList=accountDto.retrieveUsersAccountDetails(userId);
		 if (accountList==null || accountList.isEmpty()) {
				throw new ResourceNotFoundException("User Id not found : = "+userId);
		 }
		 
		return accountList;
	}
	//implementation with mvc --this method returning view with table for transaction on click of account number
	@GetMapping(path="/retrieveAccountDetails/retrieveTransactionDetails/{accountNo}")
	public ModelAndView retrieveTransactionDetails(Model model,@PathVariable Long accountNo){
		 List<AccountTransactionsDto> transactionList=transactionDto.retrieveUsersTransactionDetails(accountNo);
		 model.addAttribute("TransactionList",transactionList);
		return new ModelAndView("welcome");
	}
	
	//this method is returning list of transaction for account which user has selected
	@GetMapping(path="/getAccountDetails/getTransactionDetails/{accountNo}")
	public List<AccountTransactionsDto> getTransactionDetails(@PathVariable Long accountNo){
		 List<AccountTransactionsDto> transactionList=transactionDto.retrieveUsersTransactionDetails(accountNo);		
		 if (transactionList==null || transactionList.isEmpty()) {
				throw new ResourceNotFoundException("Account Number not found : "+accountNo);
		 }
		 return transactionList;
	}


}
