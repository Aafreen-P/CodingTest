package com.anz.engineering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EngineeringApplication {

	public static void main(String[] args) {
		SpringApplication.run(EngineeringApplication.class, args);
	}

}
