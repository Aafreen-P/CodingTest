package com.anz.engineering.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anz.engineering.entity.AccountTransactions;
import com.anz.engineering.repository.TransactionRepository;
@Service
public class TransactionServiceDTO {
	@Autowired
	private TransactionRepository transactionRepository;
	public List<AccountTransactions> retrieveUsersTransactionDetails(Long accountNo) {
		List<AccountTransactions> transactionList= transactionRepository.findByAccountNo(accountNo);		 
		return transactionList;
	}

}
